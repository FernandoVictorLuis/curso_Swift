//: Playground - noun: a place where people can play

import UIKit


var numeros = 0...100
for numero in numeros
    
{if numero == 0{
    // no se hace nada porque el cero es un número peculiar
    }else{
        if((numero%5) == 0){
            print("#\(numero)\t"+"Bingo!!!")
        }
        if((numero%2) == 0){
            print("#\(numero)\t"+"par")
        }
        if((numero%2) == 1){
            print("#\(numero)\t"+"impar")
        }
        if(numero >= 30 && numero <= 40){
            print("#\(numero)\t"+"Viva Swift!!!")
        }
   
    }
    
}



// "  El más simple posible, si se cumple una condición salta las siguientes 
/*
 var numeross = 1...100
 for numero in numeross
{
    if((numero%5) == 0){

    print("\(numero)\t"+"Bingo")
 
 }else
        if((numero%2) == 0){
            print("\(numero)\t"+"par")
 
        }else {
            print("\(numero)\t"+"impar")
 
        }
    if(numero >= 30 && numero <= 40){
        print("\(numero)\t"+"Viva Swift")
    }
 }
 // "
 */
